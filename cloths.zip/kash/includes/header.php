<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? $page_title : 'FASHIOFY'; ?></title>
    <link rel="stylesheet" href="style.css?v=3">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700;800&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <header class="main-header">
        <nav class="container nav-flex">
            <a href="index.php" class="logo">FASHIOFY</a>
            <ul class="nav-links">
                <li><a href="index.php">Home</a></li>
                <li class="dropdown-container">
                    <a href="men.php">Men</a>
                    <div class="dropdown-menu mega-menu">
                        <div class="menu-column">
                            <h4>Topwear</h4>
                            <ul>
                                <li><a href="search-results.php?q=Men's%20T-Shirt">T-Shirts</a></li>
                                <li><a href="search-results.php?q=Men's%20Casual%20Shirt">Casual Shirts</a></li>
                                <li><a href="search-results.php?q=Men's%20Formal%20Shirt">Formal Shirts</a></li>
                                <li><a href="search-results.php?q=Men's%20Sweatshirt">Sweatshirts</a></li>
                                <li><a href="search-results.php?q=Men's%20Jacket">Jackets</a></li>
                            </ul>
                        </div>
                        <div class="menu-column">
                            <h4>Bottomwear</h4>
                            <ul>
                                <li><a href="search-results.php?q=Men's%20Jeans">Jeans</a></li>
                                <li><a href="search-results.php?q=Men's%20Track%20Pant">Track Pants</a></li>
                                <li><a href="search-results.php?q=Men's%20Trousers">Trousers</a></li>
                                <li><a href="search-results.php?q=Men's%20Shorts">Shorts</a></li>
                            </ul>
                        </div>
                        <div class="menu-column">
                            <h4>Footwear</h4>
                            <ul>
                                <li><a href="search-results.php?q=Men's%20Sneaker">Sneakers</a></li>
                                <li><a href="search-results.php?q=Men's%20Formal%20Shoe">Formal Shoes</a></li>
                                <li><a href="search-results.php?q=Men's%20Sports%20Shoe">Sports Shoes</a></li>
                                <li><a href="search-results.php?q=Men's%20Sandals">Sandals</a></li>
                            </ul>
                        </div>
                        <div class="menu-column">
                            <h4>Accessories</h4>
                            <ul>
                                <li><a href="search-results.php?q=Men's%20Watch">Watchs</a></li>
                                <li><a href="search-results.php?q=Men's%20Sunglasses">Sunglasses</a></li>
                                <li><a href="search-results.php?q=Men's%20Belt">Belts</a></li>
                                <li><a href="search-results.php?q=Men's%20Wallet">Wallets</a></li>
                            </ul>
                        </div>
                    </div>
                </li>
                <li class="dropdown-container">
                    <a href="women.php">Women</a>
                    <div class="dropdown-menu mega-menu">
                        <div class="menu-column">
                            <h4>Western Wear</h4>
                            <ul>
                                <li><a href="search-results.php?q=Women's%20Dresses">Dresses</a></li>
                                <li><a href="search-results.php?q=Women's%20Top">Tops</a></li>
                                <li><a href="search-results.php?q=Women's%20T-Shirt">T-Shirts</a></li>
                                <li><a href="search-results.php?q=Women's%20Jeans">Jeans</a></li>
                                <li><a href="search-results.php?q=Women's%20Trousers">Trousers</a></li>
                            </ul>
                        </div>
                        <div class="menu-column">
                            <h4>Ethnic Wear</h4>
                            <ul>
                                <li><a href="search-results.php?q=Women's%20Kurta">Kurtas</a></li>
                                <li><a href="search-results.php?q=Women's%20Saree">Sarees</a></li>
                                <li><a href="search-results.php?q=Women's%20Ethnic%20Dresse">Ethnic Dresses</a></li>
                                <li><a href="search-results.php?q=Women's%20Lehenga">Lehengas</a></li>
                            </ul>
                        </div>
                        <div class="menu-column">
                            <h4>Footwear</h4>
                            <ul>
                                <li><a href="search-results.php?q=Women's%20Heels">Heels</a></li>
                                <li><a href="search-results.php?q=Women's%20Flats">Flats</a></li>
                                <li><a href="search-results.php?q=Women's%20Casual%20Shoe">Casual Shoes</a></li>
                                <li><a href="search-results.php?q=Women's%20Boots">Boots</a></li>
                            </ul>
                        </div>
                        <div class="menu-column">
                            <h4>Beauty & Styling</h4>
                            <ul>
                                <li><a href="search-results.php?q=Women's%20Makeup">Makeup</a></li>
                                <li><a href="search-results.php?q=Women's%20Skincare">Skincare</a></li>
                                <li><a href="search-results.php?q=Women's%20Premium%20Fragrances">Premium Fragrancess</a></li>
                                <li><a href="search-results.php?q=Women's%20Jewellery">Jewellery</a></li>
                            </ul>
                        </div>
                    </div>
                </li>
                <li class="dropdown-container">
                    <a href="kids.php">Kids</a>
                    <div class="dropdown-menu mega-menu">
                        <div class="menu-column">
                            <h4>Boys Clothing</h4>
                            <ul>
                                <li><a href="search-results.php?q=Kids's%20T-Shirt">T-Shirts</a></li>
                                <li><a href="search-results.php?q=Kids's%20Shirt">Shirts</a></li>
                                <li><a href="search-results.php?q=Kids's%20Shorts">Shorts</a></li>
                                <li><a href="search-results.php?q=Kids's%20Jeans">Jeans</a></li>
                                <li><a href="search-results.php?q=Kids's%20Ethnic%20Wear">Ethnic Wear</a></li>
                            </ul>
                        </div>
                        <div class="menu-column">
                            <h4>Girls Clothing</h4>
                            <ul>
                                <li><a href="search-results.php?q=Kids's%20Dresses">Dresses</a></li>
                                <li><a href="search-results.php?q=Kids's%20Top">Tops</a></li>
                                <li><a href="search-results.php?q=Kids's%20Skirt">Skirts</a></li>
                                <li><a href="search-results.php?q=Kids's%20Jeans">Jeans</a></li>
                                <li><a href="search-results.php?q=Kids's%20Ethnic%20Wear">Ethnic Wear</a></li>
                            </ul>
                        </div>
                        <div class="menu-column">
                            <h4>Footwear</h4>
                            <ul>
                                <li><a href="search-results.php?q=Kids's%20Casual%20Shoe">Casual Shoes</a></li>
                                <li><a href="search-results.php?q=Kids's%20Sports%20Shoe">Sports Shoes</a></li>
                                <li><a href="search-results.php?q=Kids's%20Sandals">Sandals</a></li>
                                <li><a href="search-results.php?q=Kids's%20School%20Shoe">School Shoes</a></li>
                            </ul>
                        </div>
                        <div class="menu-column">
                            <h4>Toys & More</h4>
                            <ul>
                                <li><a href="search-results.php?q=Kids's%20Soft%20Toy">Soft Toys</a></li>
                                <li><a href="search-results.php?q=Kids's%20Action%20Figure">Action Figures</a></li>
                                <li><a href="search-results.php?q=Kids's%20Educational%20Toy">Educational Toys</a></li>
                                <li><a href="search-results.php?q=Kids's%20Backpack">Backpacks</a></li>
                            </ul>
                        </div>
                    </div>
                </li>
                <li><a href="wishlist.php">Wishlist <span id="header-wishlist-count" style="background:#e74c3c; color:white; border-radius:50%; padding:2px 6px; font-size:0.7rem; font-weight:bold; display:none;">0</span></a></li>
            </ul>
            <form class="search-form" onsubmit="event.preventDefault();">
                <input id="search-input" class="search-bar" type="text" placeholder="Search products by name...">
            </form>
            
            <div class="header-actions">
                <div class="profile-dropdown-container">
                    <div class="profile-nav-item">
                        <i class="far fa-user"></i>
                        <span class="nav-label">Profile</span>
                        <?php if(isset($_SESSION['user_email'])): ?>
                            <span class="user-name-header"><?php echo htmlspecialchars(explode('@', $_SESSION['user_email'])[0]); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="profile-dropdown">
                        <?php if(isset($_SESSION['user_email'])): ?>
                            <div class="dropdown-user-info">
                                <p class="welcome-text">Welcome back,</p>
                                <p class="user-email-display"><?php echo htmlspecialchars($_SESSION['user_email']); ?></p>
                            </div>
                            <hr>
                        <?php endif; ?>
                        <a href="profile.php"><i class="far fa-id-card"></i> My Profile</a>
                        <a href="order-history.php"><i class="fas fa-box-open"></i> Order History</a>
                        <a href="offers.php"><i class="fas fa-gift"></i> Offers</a>
                        <a href="discounts.php"><i class="fas fa-percentage"></i> Discounts</a>
                        <hr>
                        <?php if(isset($_SESSION['user_email'])): ?>
                            <a href="logout.php" class="logout-link"><i class="fas fa-sign-out-alt"></i> Logout</a>
                        <?php else: ?>
                            <a href="login.php" class="login-link"><i class="fas fa-sign-in-alt"></i> Login / Register</a>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="cart-icon" onclick="toggleCart()">
                    <i class="fas fa-shopping-bag"></i>
                    <span id="cart-count">0</span>
                    <span class="nav-label">Bag</span>
                </div>
            </div>
        </nav>
    </header>
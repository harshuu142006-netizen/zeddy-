    <footer>
        <div class="container footer-grid">
            <div>
                <h3>FASHIOFY</h3>
                <p style="font-size: 0.9rem; margin-top: 10px; color: #bbb;">Defining modern style for the next generation.</p>
            </div>
            <div>
                <h4>Explore</h4>
                <p><a href="men.php" style="color:#bbb; text-decoration:none;">Men's Collection</a></p>
                <p><a href="women.php" style="color:#bbb; text-decoration:none;">Women's Collection</a></p>
                <p><a href="order-tracking.php" style="color:#bbb; text-decoration:none;">Track Order</a></p>
            </div>
            <div>
                <h4>Newsletter</h4>
                <input type="email" placeholder="Your Email" style="width: 100%; padding: 10px; margin-top: 10px;">
            </div>
        </div>
        <div class="copyright">&copy; 2026 FASHIOFY</div>
    <!-- Chatbot Components -->
    <link rel="stylesheet" href="chatbot.css">
    
    <div id="chatbot-trigger" class="chatbot-trigger">
        <span>💬</span>
    </div>

    <div id="chatbot-window" class="chatbot-window">
        <div class="chatbot-header">
            <div class="avatar">✨</div>
            <div class="title-box">
                <h3>Style Assistant</h3>
                <span>Powered by FASHIOFY AI</span>
            </div>
        </div>
        <div id="chatbot-messages" class="chatbot-messages">
            <div id="chat-anchor"></div>
        </div>
        <div id="quick-replies" class="quick-replies"></div>
        <div class="chat-input-area">
            <input type="text" id="chat-text-input" placeholder="Or type what you're looking for..." autocomplete="off">
            <button id="chat-send-btn" class="chat-send-btn">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"></line><polygon points="22 2 15 22 11 13 2 9 22 2"></polygon></svg>
            </button>
        </div>
    </div>

    <script src="script.js?v=3"></script>
    <script src="chatbot.js"></script>
</body>
</html>